"""
geometry.py

Skeleton for orientation-independent geometry engine.
"""

from dataclasses import dataclass
from shapely.geometry import Point
import math

@dataclass
class ReceiverNode:
    id:int
    line:int
    station:int
    x:float
    y:float
    inside_boundary:bool

@dataclass
class ShotPoint:
    id:int
    line:int
    station:int
    x:float
    y:float
    inside_boundary:bool

class Geometry:
    def __init__(self, survey, gis):
        self.survey = survey
        self.gis = gis
        self.receivers = []
        self.shots = []

        theta = math.radians(survey.receiver_line_azimuth)

        self.rx_station = (math.sin(theta), math.cos(theta))
        self.rx_line = (-math.cos(theta), math.sin(theta))

        self.src_station = self.rx_line
        self.src_line = self.rx_station

    def generate(self):
        raise NotImplementedError(
            "Projection-based rotated geometry generator not yet implemented."
        )
