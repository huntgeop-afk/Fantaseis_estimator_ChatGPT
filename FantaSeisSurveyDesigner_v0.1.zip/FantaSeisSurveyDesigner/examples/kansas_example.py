
from fantaseis.models import Survey
from fantaseis.geometry import GeometryEngine

survey=Survey(
    width=15840,
    height=15840,
    receiver_line_spacing=440,
    receiver_interval=110,
    receiver_lines_per_patch=12,
    spare_receiver_lines=1,
    source_line_spacing=660,
    source_interval=220,
)

g=GeometryEngine(survey).build()

print("Receivers:",len(g.receiver_x))
print("Shots:",len(g.shot_x))
