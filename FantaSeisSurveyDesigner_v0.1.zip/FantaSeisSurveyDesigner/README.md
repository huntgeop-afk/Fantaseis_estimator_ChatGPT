
# FantaSeis Survey Designer

Version 0.1 - Geometry Engine

Roadmap:
1. Geometry engine
2. Fold/offset/azimuth analysis
3. Scheduler
4. Cost model
5. Optimizer
