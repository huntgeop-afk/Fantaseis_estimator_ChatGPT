from dataclasses import dataclass


@dataclass
class ReceiverNode:

    id: int

    line: int

    station: int

    x: float

    y: float

    inside_boundary: bool = False


@dataclass
class ShotPoint:

    id: int

    line: int

    station: int

    x: float

    y: float

    inside_boundary: bool = False


class Geometry:

    def __init__(self, survey, boundary):

        self.survey = survey
        self.boundary = boundary

        self.receivers = []
        self.shots = []

    def generate(self):

        self.generate_receivers()

        self.generate_shots()

    ########################################################

    def generate_receivers(self):

        xmin, ymin, xmax, ymax = self.boundary.total_bounds

        receiver_id = 1

        line = 1

        y = ymin

        while y <= ymax + 0.001:

            station = 1

            x = xmin

            while x <= xmax + 0.001:

                point = ReceiverNode(

                    receiver_id,

                    line,

                    station,

                    x,

                    y

                )

                point.inside_boundary = self.boundary.contains(
                    point=(x, y)
                ).any()

                self.receivers.append(point)

                receiver_id += 1

                station += 1

                x += self.survey.receiver_interval

            line += 1

            y += self.survey.receiver_line_spacing

    ########################################################

    def generate_shots(self):

        xmin, ymin, xmax, ymax = self.boundary.total_bounds

        shot_id = 1

        line = 1

        x = xmin

        while x <= xmax + 0.001:

            station = 1

            y = ymin

            while y <= ymax + 0.001:

                shot = ShotPoint(

                    shot_id,

                    line,

                    station,

                    x,

                    y

                )

                shot.inside_boundary = self.boundary.contains(
                    point=(x, y)
                ).any()

                self.shots.append(shot)

                shot_id += 1

                station += 1

                y += self.survey.shot_interval

            line += 1

            x += self.survey.source_line_spacing